export class Infos {
    RS: string = "";
    activite: string = "";
    ca: number = 0;
    nbSalaries: number = 0;
    mvmtConfie: number = 0;
    autresBq1: string = "";
    mvmtAutresBq1: string = "";
    autresBq2: string = "";
    mvmtAutresBq2: string = "";
    autresBq3: string = "";
    mvmtAutresBq3: string = "";
    cltATitrePerso: string = "";
    statutDirigeant: string = "";
    iciAgence: string = "";
    iciCompte: string = "";
    iciLC: string = "";
    dateRdv: string = "";

//---------------------------------
    encaissements: [] = [];
    paiements : [] =[];
    particuliers_e_part: number = 0;
    particuliers_e_delai: number = 0;
    particuliers_d_part: number = 0;
    particuliers_d_delai: number = 0;
    professionnels_e_part: number = 0;
    professionnels_e_delai: number = 0;
    professionnels_d_part: number = 0;
    professionnels_d_delai: number = 0;
    administrations_e_part: number = 0;
    administrations_e_delai: number = 0;
    administrations_d_part: number = 0;
    administrations_d_delai: number = 0;
//---------------------------------
    nomCollab: string = "";
    prenomCollab: string = "";
    mailCollab: string = "";
    telCollab: string = "";
    agenceCollab: string = "";
//---------------------------------
    reduction: string = "";
    tarifreel:number=0;
//---------------------------------
    basket:any=[];

}